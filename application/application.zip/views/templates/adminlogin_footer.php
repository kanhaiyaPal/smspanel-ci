<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div id="h_footer">
  <div style="width:1003px; margin:auto">
    <div style="float:right; padding-right:10px">&nbsp;</div>
    <div style="float:left; padding-left:10px">Copyrignt © 2009-2035, All rights reserved</div>
  </div>
</div>
</center>

</body></html>