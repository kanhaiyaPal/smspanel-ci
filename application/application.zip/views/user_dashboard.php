<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content">
	<!-- Tab panes -->
	<div class="tab-content">
	  <div class="tab-pane <?php if(isset($pageset) && $pageset!=''){ }else{ echo 'active'; }?>" id="dashboard" role="tabpanel"><?php echo $dashboard; ?></div>
	  <div class="tab-pane" id="managetemplates" role="tabpanel"><?php echo $templates; ?></div>
	  <div class="tab-pane" id="uploadcontact" role="tabpanel"><?php echo $content; ?></div>
	  <div class="tab-pane" id="composesms" role="tabpanel"><?php echo $compose; ?></div>
	  <div class="tab-pane" id="smshistory" role="tabpanel"><?php echo $history; ?></div>
	  <div class="tab-pane" id="offers" role="tabpanel"><?php echo $offers; ?></div>
	  <div class="tab-pane" id="smsidea" role="tabpanel"><?php echo $idea; ?></div>
	  <div class="tab-pane" id="report" role="tabpanel"><?php echo $report; ?></div>
	  <div class="tab-pane <?php if(isset($pageset) && $pageset!=''){ echo 'active'; }?>" id="notification"  role="tabpanel"><?php echo $notification; ?></div>
	</div>
	<!--.Tab panes -->
</div>
<div style="clear:both">&nbsp;</div>